package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(name = "email") WebElement userField;
    @FindBy(name = "password") WebElement passwordField;
    @FindBy(tagName = "button") WebElement loginButton;
    @FindBy(css = "[type='button'] svg") WebElement eyeIcon;

    public boolean isLoginButtonEnabled() {
        return loginButton.isEnabled();
    }

    public boolean isPasswordMasked() {
        return passwordField.getAttribute("type").equals("password");
    }

    public void enterCredentials(String email, String pass) {
        userField.sendKeys(email);
        passwordField.sendKeys(pass);
    }

    public void clickLogin() {
        loginButton.click();
    }

    public void togglePasswordVisibility() {
        eyeIcon.click();
    }

    public String getErrorMessage() {
        try {
            WebElement errorMsg = driver.findElement(By.className("text-error"));
            return errorMsg.getText();
        } catch (NoSuchElementException e) {
            return "No error";
        }
    }
}
