package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginTests extends BaseTest {

    @Test
    public void testLoginButtonDisabledWhenFieldsAreEmpty() {
        LoginPage loginPage = new LoginPage(driver);
        Assert.assertFalse(loginPage.isLoginButtonEnabled());
    }

    @Test
    public void testPasswordMaskedByDefault() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterCredentials("dummy", "secret123");
        Assert.assertTrue(loginPage.isPasswordMasked());
    }

    @Test
    public void testInvalidLoginShowErrorMsg() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterCredentials("wrong@janitri.in", "wrongpass");
        loginPage.clickLogin();
        String errorMsg = loginPage.getErrorMessage();
        System.out.println("Error Message: " + errorMsg);
        Assert.assertTrue(errorMsg.toLowerCase().contains("invalid"));
    }

    @Test
    public void testPasswordVisibilityToggle() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterCredentials("dummy", "secret123");
        loginPage.togglePasswordVisibility();
        Assert.assertFalse(loginPage.isPasswordMasked());
    }
}
